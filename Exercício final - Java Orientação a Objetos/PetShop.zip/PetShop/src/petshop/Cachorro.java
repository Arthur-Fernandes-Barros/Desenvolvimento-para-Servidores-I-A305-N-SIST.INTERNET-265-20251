/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package petshop;

public class Cachorro extends Animal {
    private String raca;

    public Cachorro(String nome, int idade, String raca) {
        super(nome, idade);
        this.raca = raca;
    }

    @Override
    public void emitirSom() {
        System.out.println(getNome() + " diz: Au Au!");
    }

    // Sobrecarga
    public void brincar() {
        System.out.println(getNome() + " está brincando com um osso.");
    }

    public void brincar(String brinquedo) {
        System.out.println(getNome() + " está brincando com " + brinquedo + ".");
    }
}