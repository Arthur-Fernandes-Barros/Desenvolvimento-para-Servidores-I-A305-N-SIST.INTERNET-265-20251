package petshop;
 public class PetShop {
 public static void main(String[] args) {
 Cachorro dog = new Cachorro("Rex", 3, "Labrador");
 Gato cat = new Gato("Mimi", 2, true);
 dog.emitirSom();
 cat.emitirSom(); 
 dog.alimentar();
 dog.alimentar("carne");

 dog.brincar("bola");
 cat.arranhar();
 }
 }