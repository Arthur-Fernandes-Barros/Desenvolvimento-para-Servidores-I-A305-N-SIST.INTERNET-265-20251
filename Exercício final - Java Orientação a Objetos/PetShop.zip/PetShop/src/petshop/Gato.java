/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package petshop;

public class Gato extends Animal {
    private boolean temPelosLongos;

    public Gato(String nome, int idade, boolean temPelosLongos) {
        super(nome, idade);
        this.temPelosLongos = temPelosLongos;
    }

    @Override
    public void emitirSom() {
        System.out.println(getNome() + " diz: Miau!");
    }

    public void arranhar() {
        System.out.println(getNome() + " está arranhando o sofá!");
    }
}